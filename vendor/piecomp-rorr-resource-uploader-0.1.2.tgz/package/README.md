# @piecomp/rorr-resource-uploader

VRM Expression Editor의 "리소스 업로드" 버튼이 쓰는 모듈. 에디터 폴더의 캐릭터 리소스를 RORR **dev** 버킷에 올린다.
구현 요청과 사용 안내: 노션 "에디터 업로드 기능 (구현 요청 + 사용 안내)".

## 설치

받은 묶음 파일을 에디터 repo에 넣고 설치한다.

```bash
npm install ./vendor/piecomp-rorr-resource-uploader-<버전>.tgz
```

업데이트할 때는 새 파일로 바꾸고 같은 명령을 다시 실행한다. Node 20 이상(Electron main 프로세스)에서 동작한다.

## 사용 (Electron main 프로세스)

```js
const { plan, run } = require('@piecomp/rorr-resource-uploader')

const p = await plan({
  characterId: 'seoha-rorr',
  awsProfile: 'rorr-resources-dev',      // ~/.aws/credentials의 프로필 이름
  sources: { vrmPath, animationsDir, imageDir, propsDir, effectsMetaPath, emotionLinkerDir },
})
// p.files     [{ key, localPath, status: 'added'|'changed'|'remoteOnly', size }]
// p.errors    [{ code, message, file }]   있으면 업로드 불가
// p.warnings  [{ code, message, file }]   unknownField·removedField = "익스텐션 담당 확인 필요"
// p.canUpload boolean

const r = await run(p, {
  note: '메모', by: '업로더 이름', editorVersion: '버전',
  onProgress: ({ stage, done, total, key }) => {},   // stage === 'verify'이면 "CDN 확인 중"
})
// 성공: { ok: true, uploaded, invalidationId, recordKey, verify }
// 실패: { ok: false, stage: 'check'|'upload'|'invalidate'|'verify'|'record', code, message, verify? }
//       code NO_CREDENTIALS·ACCESS_DENIED → "업로드 권한이 설정되지 않았습니다"
```

- 서버 파일을 지우지 않는다. 에디터 로컬 파일을 바꾸지 않는다.
- 업로드 순서: 이미지·GLB·VRM·VRMA 먼저, meta 마지막. 업로드 후 캐시 무효화를 기다려 CDN에서 확인한다(최대 5분).
- 제외: 백업·임시 파일(`*.bak`, `*_bk.*`, `*.broken-*` 등), `.ini`. `spaces/`, `vrSpace/`는 원본으로 쓸 수 없다.

## 명령어로 미리 보기 (dry-run)

서버를 읽기만 한다.

```bash
npx rorr-upload --editor <에디터 폴더> --vrm <VRM 파일> --profile rorr-resources-dev
```
