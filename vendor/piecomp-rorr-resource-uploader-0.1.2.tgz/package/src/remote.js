'use strict'

const fs = require('node:fs')
const { S3Client, ListObjectsV2Command, HeadObjectCommand, GetObjectCommand, PutObjectCommand } = require('@aws-sdk/client-s3')
const { CloudFrontClient, CreateInvalidationCommand, GetInvalidationCommand } = require('@aws-sdk/client-cloudfront')
const { fromIni } = require('@aws-sdk/credential-providers')

/**
 * 버킷·CloudFront 접근을 감싼다. 테스트에서는 같은 모양의 가짜 객체를 넘긴다.
 * 이 모듈은 삭제 기능을 일부러 갖지 않는다.
 */
function createRemote(env, { profile } = {}) {
  const credentials = profile ? fromIni({ profile }) : undefined
  const local = env.endpoint ? { endpoint: env.endpoint } : {}
  // 로컬 에뮬레이터(moto)는 SDK 기본 CRC64 체크섬을 잘못 돌려줘서 로컬에서만 끈다. 업로드 무결성은 ContentMD5로 따로 확인한다
  const s3Local = env.endpoint
    ? { forcePathStyle: true, requestChecksumCalculation: 'WHEN_REQUIRED', responseChecksumValidation: 'WHEN_REQUIRED' }
    : {}
  const s3 = new S3Client({ region: env.region, credentials, ...local, ...s3Local })
  const cf = new CloudFrontClient({ region: 'us-east-1', credentials, ...local })

  return {
    /** 접두사 아래의 객체 목록. 폴더 표시용 키(…/)는 뺀다 */
    async list(prefix) {
      const out = []
      let token
      do {
        const res = await s3.send(new ListObjectsV2Command({ Bucket: env.bucket, Prefix: prefix, ContinuationToken: token }))
        for (const o of res.Contents ?? []) {
          if (o.Key.endsWith('/')) continue
          out.push({ key: o.Key, size: o.Size, etag: o.ETag })
        }
        token = res.IsTruncated ? res.NextContinuationToken : undefined
      } while (token)
      return out
    },

    /** 업로더가 남긴 md5 메타데이터 */
    async headMd5(key) {
      const res = await s3.send(new HeadObjectCommand({ Bucket: env.bucket, Key: key }))
      return res.Metadata?.md5 ?? null
    },

    /** 텍스트 객체를 읽는다. 없으면 null */
    async getText(key) {
      try {
        const res = await s3.send(new GetObjectCommand({ Bucket: env.bucket, Key: key }))
        return await res.Body.transformToString()
      } catch (err) {
        if (err.name === 'NoSuchKey' || err.$metadata?.httpStatusCode === 404) return null
        throw err
      }
    },

    /** 객체를 로컬 파일로 받는다 (CI 기록용) */
    async download(key, localPath) {
      const res = await s3.send(new GetObjectCommand({ Bucket: env.bucket, Key: key }))
      await fs.promises.mkdir(require('node:path').dirname(localPath), { recursive: true })
      await require('node:stream/promises').pipeline(res.Body, fs.createWriteStream(localPath))
    },

    async putFile({ key, localPath, size, md5, contentType }) {
      await s3.send(
        new PutObjectCommand({
          Bucket: env.bucket,
          Key: key,
          Body: fs.createReadStream(localPath),
          ContentLength: size,
          ContentType: contentType,
          ContentMD5: Buffer.from(md5, 'hex').toString('base64'),
          Metadata: { md5 },
        }),
      )
    },

    async putJson(key, data) {
      await s3.send(
        new PutObjectCommand({ Bucket: env.bucket, Key: key, Body: JSON.stringify(data, null, 2), ContentType: 'application/json' }),
      )
    },

    async invalidate(keys) {
      const res = await cf.send(
        new CreateInvalidationCommand({
          DistributionId: env.distributionId,
          InvalidationBatch: {
            CallerReference: `rorr-upload-${Date.now()}`,
            Paths: { Quantity: keys.length, Items: keys.map((k) => `/${k.split('/').map(encodeURIComponent).join('/')}`) },
          },
        }),
      )
      return res.Invalidation?.Id ?? null
    },

    /** 무효화가 끝나면 true, 시간 안에 안 끝나면 false */
    async waitInvalidation(id, { timeoutMs = 5 * 60 * 1000, intervalMs = 10 * 1000 } = {}) {
      const deadline = Date.now() + timeoutMs
      for (;;) {
        const res = await cf.send(new GetInvalidationCommand({ DistributionId: env.distributionId, Id: id }))
        if (String(res.Invalidation?.Status).toLowerCase() === 'completed') return true
        if (Date.now() + intervalMs > deadline) return false
        await new Promise((r) => setTimeout(r, intervalMs))
      }
    },

    /** 익스텐션이 읽는 것과 같은 CDN URL로 HEAD 요청 */
    async cdnHead(key) {
      const url = `${env.cdnBaseUrl}/${key.split('/').map(encodeURIComponent).join('/')}`
      const res = await fetch(url, { method: 'HEAD', cache: 'no-store' })
      return { status: res.status, etag: res.headers.get('etag') }
    },
  }
}

module.exports = { createRemote }
