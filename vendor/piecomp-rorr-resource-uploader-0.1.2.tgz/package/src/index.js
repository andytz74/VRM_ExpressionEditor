'use strict'

const fs = require('node:fs/promises')
const path = require('node:path')
const { getEnvironment, KEYS } = require('./config')
const { collectLocalFiles, managedPrefixes, contentTypeFor } = require('./layout')
const { collectReferences, findUnknownFields, findRemovedFields, mergeSchema, checkFileNames } = require('./checks')
const { md5File, compareStatus, cleanEtag } = require('./compare')
const { createRemote } = require('./remote')

const META_ROLES = ['characterMeta', 'animationsMeta', 'effectsMeta']

/**
 * 업로드 순서. 참조되는 리소스(이미지·VRM·VRMA·GLB)를 먼저 올리고, 이를 참조하는 meta는 마지막에 올린다.
 * 중간에 실패해도 서버의 meta가 아직 없는 파일을 가리키는 상태가 생기지 않는다.
 * characterMeta는 클립 목록(animations.meta)과 효과(effects.meta)를 함께 참조하므로 가장 마지막.
 */
const UPLOAD_ORDER = ['image', 'prop', 'model', 'animation', 'emotionLinker', 'effectsMeta', 'animationsMeta', 'characterMeta']
const orderOf = (role) => {
  const i = UPLOAD_ORDER.indexOf(role)
  return i === -1 ? UPLOAD_ORDER.length : i
}

/**
 * 업로드 계획을 만든다. 서버는 읽기만 한다.
 *
 * @param {object} opts
 * @param {string} opts.characterId 예: 'seoha-rorr'
 * @param {string} [opts.awsProfile] ~/.aws/credentials 프로필 이름
 * @param {object} opts.sources 에디터 폴더 경로 { vrmPath, animationsDir, imageDir, propsDir, effectsMetaPath, emotionLinkerDir }
 * @param {object} [opts.knownFields] known-fields.json 내용. 없으면 버킷의 vrm/schema/known-fields.json을 읽는다
 * @param {'dev'|'prod'} [opts.env] 기본 dev. prod는 CI에서만 (RORR_ALLOW_PROD=1)
 * @param {object} [opts.remote] 테스트용 가짜 원격
 */
async function plan(opts) {
  const envName = opts.env ?? 'dev'
  let env
  try {
    env = getEnvironment(envName)
  } catch (err) {
    return failedPlan(opts, envName, [{ code: err.code, message: err.message, file: null }])
  }
  const errors = []
  const warnings = []

  let local
  try {
    local = await collectLocalFiles(opts.sources ?? {}, opts.characterId)
  } catch (err) {
    return failedPlan(opts, envName, [{ code: err.code ?? 'LOCAL_READ_FAILED', message: err.message, file: null }])
  }
  for (const missing of local.missingSources) {
    warnings.push({ code: 'missingSource', message: `에디터 쪽 파일이나 폴더가 없거나 비어 있습니다: ${missing}`, file: missing })
  }

  const remote = opts.remote ?? createRemote(env, { profile: opts.awsProfile })

  // 1) 서버 목록
  let remoteList
  try {
    remoteList = (await Promise.all(managedPrefixes(opts.characterId).map((p) => remote.list(p)))).flat()
  } catch (err) {
    return failedPlan(opts, envName, [toCheckError(err)])
  }
  const remoteByKey = new Map(remoteList.map((o) => [o.key, o]))

  // 2) 로컬 MD5와 비교. 크기가 같고 ETag로 판단이 안 되는 것만 HEAD로 md5 메타데이터를 읽는다
  const files = []
  for (const f of local.files) {
    const md5 = await md5File(f.localPath)
    const r = remoteByKey.get(f.key)
    let remoteInfo = r ? { size: r.size, etag: r.etag } : null
    if (r && r.size === f.size && cleanEtag(r.etag).includes('-')) {
      try {
        remoteInfo.metaMd5 = await remote.headMd5(f.key)
      } catch (err) {
        return failedPlan(opts, envName, [toCheckError(err)])
      }
    }
    files.push({ ...f, md5, status: compareStatus({ size: f.size, md5 }, remoteInfo) })
  }
  const localKeys = new Set(files.map((f) => f.key))
  const remoteOnly = remoteList
    .filter((o) => !localKeys.has(o.key))
    .map((o) => ({ key: o.key, localPath: null, status: 'remoteOnly', size: o.size }))

  // 3) meta 검사
  let knownFields = opts.knownFields ?? null
  if (!knownFields) {
    try {
      const text = await remote.getText(KEYS.knownFields)
      knownFields = text ? JSON.parse(text) : null
    } catch (err) {
      knownFields = null
    }
  }
  if (!knownFields) knownFields = bundledKnownFields()
  if (!knownFields) {
    warnings.push({ code: 'knownFieldsUnavailable', message: `검사 기준(${KEYS.knownFields})을 읽지 못해 필드 검사를 건너뜁니다`, file: null })
  }

  const root = KEYS.characterRoot(opts.characterId)
  const refKey = (folder, name) => (folder === 'animations' ? `${KEYS.sharedAnimations}/${name}` : `${root}/${folder}/${name}`)
  const existingKeys = new Set([...localKeys, ...remoteByKey.keys()])
  let listedClips = null
  const referencedKeys = new Set()

  for (const f of files.filter((x) => META_ROLES.includes(x.role))) {
    let meta
    try {
      meta = JSON.parse(await fs.readFile(f.localPath, 'utf8'))
    } catch (err) {
      errors.push({ code: 'invalidJson', message: `meta 파일을 JSON으로 읽을 수 없습니다: ${err.message}`, file: f.key })
      continue
    }
    if (f.role === 'animationsMeta') listedClips = new Set(Object.keys(meta.animations ?? {}))

    const seen = new Set()
    for (const ref of collectReferences(f.role, meta)) {
      const key = refKey(ref.folder, ref.name)
      referencedKeys.add(key)
      if (existingKeys.has(key) || seen.has(key)) continue
      seen.add(key)
      errors.push({ code: 'missingReference', message: `${ref.from}이(가) 참조하는 파일이 없습니다: ${ref.folder}/${ref.name}`, file: f.key })
    }

    const schema = knownFields?.files?.[f.role]
    if (schema) {
      // editorOnly(에디터 전용으로 인정한 필드)는 경고하지 않는다. 새로 생긴 필드만 익스텐션 담당 확인 대상
      for (const u of findUnknownFields(mergeSchema(schema, knownFields.editorOnly?.[f.role]), meta)) {
        warnings.push({ code: 'unknownField', message: `익스텐션이 모르는 새 필드 (익스텐션 담당 확인 필요): ${fieldName(u)}`, file: f.key })
      }
      // 서버 meta에 있던, 익스텐션이 읽는 필드가 빠지는지
      if (f.status === 'changed') {
        let remoteMeta = null
        try {
          const text = await remote.getText(f.key)
          remoteMeta = text ? JSON.parse(text) : null
        } catch {
          remoteMeta = null
        }
        if (remoteMeta) {
          for (const u of findRemovedFields(schema, remoteMeta, meta)) {
            warnings.push({ code: 'removedField', message: `서버 meta에 있던 필드가 빠집니다 (익스텐션 담당 확인 필요): ${fieldName(u)}`, file: f.key })
          }
        }
      }
    }
  }

  if (listedClips) {
    for (const f of files.filter((x) => x.role === 'animation' && x.key.endsWith('.vrma'))) {
      const name = path.posix.basename(f.key)
      if (!listedClips.has(name)) {
        warnings.push({ code: 'unlistedClip', message: `animations.meta에 없는 클립입니다: ${name}`, file: f.key })
      }
    }
  }

  warnings.push(...checkFileNames([...localKeys]))

  const toUpload = files
    .filter((f) => f.status === 'added' || f.status === 'changed')
    .sort((a, b) => orderOf(a.role) - orderOf(b.role))
  return {
    env: envName,
    characterId: opts.characterId,
    awsProfile: opts.awsProfile ?? null,
    files: [...toUpload.map(publicFile), ...remoteOnly],
    errors,
    warnings,
    summary: {
      added: files.filter((f) => f.status === 'added').length,
      changed: files.filter((f) => f.status === 'changed').length,
      unchanged: files.filter((f) => f.status === 'unchanged').length,
      remoteOnly: remoteOnly.length,
      skipped: local.skipped,
    },
    canUpload: errors.length === 0 && toUpload.length > 0,
    // run()에서만 쓰는 내부 정보
    _uploads: toUpload.map((f) => ({ key: f.key, localPath: f.localPath, size: f.size, md5: f.md5, role: f.role, contentType: contentTypeFor(f.key) })),
    _references: [...referencedKeys].sort(),
  }
}

/**
 * 계획대로 올린다: 파일 업로드 → 캐시 무효화 → 업로드 기록. 삭제는 하지 않는다.
 * 중간에 실패하면 다시 plan()을 부르면 이미 올라간 파일은 'unchanged'가 되어 건너뛴다.
 */
async function run(p, opts = {}) {
  if (!p?.canUpload) {
    return { ok: false, stage: 'check', code: 'NOT_UPLOADABLE', message: '업로드할 수 없는 상태입니다. 오류를 확인하거나 바뀐 파일이 있는지 확인하세요.' }
  }
  const remote = opts.remote ?? createRemote(getEnvironment(p.env), { profile: p.awsProfile })
  const total = p._uploads.length
  const uploaded = []

  for (const [i, f] of p._uploads.entries()) {
    try {
      await remote.putFile(f)
    } catch (err) {
      return { ok: false, stage: 'upload', uploaded: uploaded.length, ...toRunError(err, f.key) }
    }
    uploaded.push(f.key)
    opts.onProgress?.({ done: i + 1, total, key: f.key })
  }

  let invalidationId = null
  try {
    invalidationId = await remote.invalidate(uploaded)
  } catch (err) {
    return { ok: false, stage: 'invalidate', uploaded: uploaded.length, ...toRunError(err) }
  }

  // 익스텐션과 같은 URL 규칙으로 CDN에서 확인한다: 올린 파일이 새 내용으로 보이는지, meta가 참조하는 파일이 있는지
  opts.onProgress?.({ stage: 'verify', done: total, total })
  let verify
  try {
    verify = await verifyOnCdn(remote, p, invalidationId, opts)
  } catch (err) {
    verify = { ok: false, problems: [{ code: 'VERIFY_ERROR', key: null, message: err?.message ?? String(err) }] }
  }

  const at = new Date()
  const recordKey = `${KEYS.uploadRecords}/${at.toISOString().replace(/[:.]/g, '-')}.json`
  try {
    await remote.putJson(recordKey, {
      at: at.toISOString(),
      by: opts.by ?? null,
      note: opts.note ?? '',
      character: p.characterId,
      editorVersion: opts.editorVersion ?? null,
      files: p._uploads.map(({ key, md5, size }) => ({ key, md5, size })),
      warnings: p.warnings.map((w) => w.message),
      invalidationId,
      verify,
    })
  } catch (err) {
    return { ok: false, stage: 'record', uploaded: uploaded.length, invalidationId, verify, ...toRunError(err) }
  }

  if (!verify.ok) {
    return {
      ok: false,
      stage: 'verify',
      code: 'VERIFY_FAILED',
      message: 'S3 업로드는 끝났지만 CDN 확인에서 문제가 있습니다. 익스텐션 담당자에게 알려 주세요.',
      uploaded: uploaded.length,
      invalidationId,
      recordKey,
      verify,
    }
  }
  return { ok: true, uploaded: uploaded.length, invalidationId, recordKey, verify }
}

/**
 * CDN 확인.
 * 1. 캐시 무효화가 끝날 때까지 기다린다 (기본 최대 5분)
 *    상태 조회(GetInvalidation)가 권한 등으로 실패하면 기다리기를 건너뛰고, 3~4를 시간 안에 반복해서 확인한다
 * 2. 올린 파일: CDN 응답 200, ETag가 올린 파일의 MD5와 같은지 (PutObject는 단일 업로드라 ETag = MD5)
 * 3. meta가 참조하는 파일: CDN 응답 200
 */
async function verifyOnCdn(remote, p, invalidationId, opts) {
  const problems = []
  const timeoutMs = opts.verifyTimeoutMs ?? 5 * 60 * 1000
  const intervalMs = opts.verifyIntervalMs ?? 10 * 1000
  const deadline = Date.now() + timeoutMs
  let invalidationWait = 'none'
  if (invalidationId && remote.waitInvalidation) {
    try {
      const done = await remote.waitInvalidation(invalidationId, { timeoutMs })
      invalidationWait = done ? 'completed' : 'timeout'
      if (!done) problems.push({ code: 'INVALIDATION_TIMEOUT', key: null, message: `캐시 무효화가 ${Math.round(timeoutMs / 1000)}초 안에 끝나지 않았습니다` })
    } catch (err) {
      // 무효화 요청은 이미 들어갔다. 상태만 못 보는 것이므로 CDN을 직접 반복 확인한다
      invalidationWait = `skipped (${classify(err)})`
    }
  }
  const pollCdn = invalidationWait.startsWith('skipped')

  const uploadedMd5 = new Map(p._uploads.map((f) => [f.key, f.md5]))
  const keys = [...new Set([...uploadedMd5.keys(), ...(p._references ?? [])])]
  let pending = keys
  let cdnProblems = []
  for (;;) {
    cdnProblems = []
    for (const key of pending) {
      const res = await remote.cdnHead(key)
      if (res.status !== 200) {
        cdnProblems.push({ code: 'CDN_NOT_FOUND', key, message: `CDN에서 열리지 않습니다 (HTTP ${res.status})` })
        continue
      }
      const expected = uploadedMd5.get(key)
      if (expected && cleanEtag(res.etag).toLowerCase() !== expected) {
        cdnProblems.push({ code: 'CDN_STALE', key, message: 'CDN이 아직 이전 내용을 돌려줍니다' })
      }
    }
    if (!cdnProblems.length || !pollCdn || Date.now() + intervalMs > deadline) break
    pending = cdnProblems.map((x) => x.key)
    await new Promise((r) => setTimeout(r, intervalMs))
  }
  problems.push(...cdnProblems)
  return { ok: problems.length === 0, checked: keys.length, invalidationWait, problems }
}

/** 패키지에 들어 있는 검사 기준 사본 (npm pack 때 schema/에서 복사). 버킷 기준을 못 읽을 때만 쓴다 */
function bundledKnownFields() {
  try {
    return require('../known-fields.json')
  } catch {
    return null
  }
}

function fieldName(u) {
  return `${u.path === '(root)' ? '' : `${u.path}.`}${u.field}`
}

function publicFile({ key, localPath, status, size }) {
  return { key, localPath, status, size }
}

function failedPlan(opts, envName, errors) {
  return {
    env: envName,
    characterId: opts.characterId,
    awsProfile: opts.awsProfile ?? null,
    files: [],
    errors,
    warnings: [],
    summary: { added: 0, changed: 0, unchanged: 0, remoteOnly: 0, skipped: [] },
    canUpload: false,
    _uploads: [],
    _references: [],
  }
}

function classify(err) {
  const name = err?.name ?? ''
  if (name === 'CredentialsProviderError' || /Could not load credentials|profile .* could not be found/i.test(err?.message ?? '')) return 'NO_CREDENTIALS'
  if (name === 'AccessDenied' || err?.$metadata?.httpStatusCode === 403) return 'ACCESS_DENIED'
  return name || 'UNKNOWN'
}

function toCheckError(err) {
  return { code: classify(err), message: err?.message ?? String(err), file: null }
}

function toRunError(err, key) {
  return { code: classify(err), message: `${key ? `${key}: ` : ''}${err?.message ?? String(err)}` }
}

module.exports = { plan, run }
