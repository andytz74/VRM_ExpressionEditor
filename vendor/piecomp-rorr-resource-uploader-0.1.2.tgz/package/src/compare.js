'use strict'

const crypto = require('node:crypto')
const fs = require('node:fs')

/** 파일의 MD5(hex) */
function md5File(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('md5')
    fs.createReadStream(filePath)
      .on('error', reject)
      .on('data', (chunk) => hash.update(chunk))
      .on('end', () => resolve(hash.digest('hex')))
  })
}

/** S3 ETag에서 따옴표를 뗀다 */
function cleanEtag(etag) {
  return String(etag ?? '').replace(/"/g, '')
}

/**
 * 서버 객체의 MD5를 알아낸다.
 * 1. 업로더가 남긴 `x-amz-meta-md5`
 * 2. ETag에 `-`가 없으면(단일 업로드) ETag 자체가 MD5
 * 3. 그 외(분할 업로드된 기존 파일)는 알 수 없음 → null
 */
function remoteMd5({ etag, metaMd5 }) {
  if (metaMd5) return metaMd5.toLowerCase()
  const e = cleanEtag(etag)
  if (e && !e.includes('-')) return e.toLowerCase()
  return null
}

/**
 * 로컬 파일과 서버 객체를 비교해 상태를 정한다.
 * MD5를 알 수 없으면 안전하게 'changed'로 본다 — 첫 업로드 때 큰 파일이 한 번 다시 올라갈 수 있다.
 *
 * @returns {'added'|'changed'|'unchanged'}
 */
function compareStatus(local, remote) {
  if (!remote) return 'added'
  if (remote.size !== local.size) return 'changed'
  const r = remoteMd5(remote)
  if (!r) return 'changed'
  return r === local.md5 ? 'unchanged' : 'changed'
}

module.exports = { md5File, cleanEtag, remoteMd5, compareStatus }
