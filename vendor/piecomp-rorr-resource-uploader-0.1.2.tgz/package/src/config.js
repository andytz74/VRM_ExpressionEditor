'use strict'

/**
 * 업로드 대상 환경. 에디터는 dev만 다룬다 — prod는 리소스 레포 main 머지로만 반영된다.
 * 규칙: 상위 노션 페이지 "디렉토리 정책"과 익스텐션 `src/side-panel/shared/lib/vrm/paths.ts`.
 */
const ENVIRONMENTS = {
  dev: {
    bucket: 'ai-rorr-develop-frontend-resources',
    // get-bucket-location이 LocationConstraint null을 돌려준다 = us-east-1
    region: 'us-east-1',
    distributionId: 'E3F8GEV91YS2PR',
    cdnBaseUrl: 'https://ai-dev-resources.rorr.club',
  },
}

/**
 * 로컬 테스트(moto 등 S3·CloudFront 에뮬레이터)용. RORR_LOCAL_ENDPOINT가 있을 때만 적용된다.
 * RORR_DEV_DISTRIBUTION_ID·RORR_DEV_CDN_BASE_URL로 dev 값을 바꿀 수 있다.
 */
function withLocalOverrides(env, prefix) {
  const endpoint = process.env.RORR_LOCAL_ENDPOINT
  if (!endpoint) return env
  return {
    ...env,
    endpoint,
    distributionId: process.env[`${prefix}_DISTRIBUTION_ID`] || env.distributionId,
    cdnBaseUrl: process.env[`${prefix}_CDN_BASE_URL`] || env.cdnBaseUrl,
  }
}

/**
 * prod는 CI(리소스 레포 main 머지)에서만 쓴다. 버킷·배포 ID는 레포 변수로 받는다 — 에디터 PC에는 값도 권한도 없다.
 * RORR_ALLOW_PROD=1이 없으면 거부한다.
 */
function getEnvironment(name) {
  if (name === 'dev') return withLocalOverrides(ENVIRONMENTS.dev, 'RORR_DEV')
  if (name === 'prod') {
    if (process.env.RORR_ALLOW_PROD !== '1') {
      throw Object.assign(new Error('prod는 리소스 레포 CI에서만 다룹니다'), { code: 'PROD_NOT_ALLOWED' })
    }
    const missing = ['RORR_PROD_BUCKET', 'RORR_PROD_DISTRIBUTION_ID'].filter((k) => !process.env[k])
    if (missing.length) throw Object.assign(new Error(`prod 설정이 없습니다: ${missing.join(', ')}`), { code: 'PROD_CONFIG_MISSING' })
    return withLocalOverrides({
      bucket: process.env.RORR_PROD_BUCKET,
      region: process.env.RORR_PROD_REGION || 'us-east-1',
      distributionId: process.env.RORR_PROD_DISTRIBUTION_ID,
      cdnBaseUrl: process.env.RORR_PROD_CDN_BASE_URL || 'https://ai-prod-resources.rorr.club',
    }, 'RORR_PROD')
  }
  throw Object.assign(new Error(`알 수 없는 환경: ${name}`), { code: 'UNKNOWN_ENV' })
}

/** 버킷 안의 경로 규칙 */
const KEYS = {
  characterRoot: (characterId) => `vrm/characters/${characterId}`,
  sharedAnimations: 'vrm/characters/vrma',
  uploadRecords: 'vrm/_uploads',
  knownFields: 'vrm/schema/known-fields.json',
}

/** 캐릭터 id 규칙 — 폴더는 케밥 케이스, 모델 파일은 같은 이름의 스네이크 케이스 */
const CHARACTER_ID = /^[a-z0-9]+(?:-[a-z0-9]+)*$/

function modelFileBase(characterId) {
  return characterId.replace(/-/g, '_')
}

module.exports = { ENVIRONMENTS, getEnvironment, KEYS, CHARACTER_ID, modelFileBase }
