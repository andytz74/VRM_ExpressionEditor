'use strict'

const path = require('node:path')

/**
 * meta가 참조하는 리소스 파일을 모은다. 참조값은 확장자를 포함한 파일 이름이고 폴더는 런타임이 붙인다
 * (익스텐션 `paths.ts`). 반환값의 folder는 버킷 키를 만들 때 쓴다.
 *
 * @returns {Array<{folder:'img'|'props'|'animations', name:string, from:string}>}
 */
function collectReferences(role, meta) {
  const refs = []
  const push = (folder, name, from) => {
    if (typeof name === 'string' && name.trim()) refs.push({ folder, name: name.trim(), from })
  }

  if (role === 'characterMeta') {
    push('img', meta.blush?.image, 'blush')
    push('img', meta.emotionImage?.image, 'emotionImage')
    for (const preset of arr(meta.expressionPresets)) {
      push('img', preset?.emotionImage?.image, `expressionPresets[${preset?.name ?? preset?.id}].emotionImage`)
      for (const slot of arr(preset?.rangeSlots)) {
        push('img', slot?.emotionImage?.image, `expressionPresets[${preset?.name ?? preset?.id}].rangeSlots[${slot?.id}].emotionImage`)
      }
    }
    for (const prop of arr(meta.props)) push('props', prop?.file, `props[${prop?.id}]`)
    for (const clip of Object.keys(obj(meta.animations))) push('animations', clip, 'animations')
    for (const slot of arr(meta.motionSlots)) push('animations', slot?.animationFile, `motionSlots[${slot?.id}]`)
  }

  if (role === 'effectsMeta') {
    for (const effect of arr(meta.effects)) {
      for (const particle of arr(effect?.particles)) {
        push('img', particle?.texture?.image, `effects[${effect?.id}].particles[${particle?.id}].texture`)
      }
    }
  }

  if (role === 'animationsMeta') {
    for (const clip of Object.keys(obj(meta.animations))) push('animations', clip, 'animations')
  }

  return refs
}

/**
 * known-fields 스키마로 meta를 훑어 익스텐션이 모르는 필드를 찾는다. 같은 경로는 한 번만 보고한다.
 *
 * @param {object} schema known-fields.json의 files[역할]
 * @returns {Array<{path:string, field:string}>}
 */
function findUnknownFields(schema, meta) {
  const found = new Map()

  const walk = (value, pattern) => {
    if (Array.isArray(value)) {
      for (const item of value) walk(item, `${pattern}[]`)
      return
    }
    if (!value || typeof value !== 'object') return

    const isMap = Object.prototype.hasOwnProperty.call(schema, join(pattern, '*'))
    const known = schema[pattern]
    for (const [key, child] of Object.entries(value)) {
      if (!isMap && known && !known.includes(key)) {
        const id = `${pattern}|${key}`
        if (!found.has(id)) found.set(id, { path: pattern || '(root)', field: key })
        continue
      }
      walk(child, join(pattern, isMap ? '*' : key))
    }
  }

  walk(meta, '')
  return [...found.values()]
}

/**
 * 스키마가 검사하는 객체 위치(패턴)마다 실제로 들어 있는 필드를 모은다. 맵(.*)의 키, 스키마에 없는 위치는 모으지 않는다.
 * @returns {{fields: Set<string>, patterns: Set<string>}} fields는 `패턴|필드`, patterns는 meta에 실제로 있는 객체 위치
 */
function collectFieldPaths(schema, meta) {
  const fields = new Set()
  const patterns = new Set()
  const walk = (value, pattern) => {
    if (Array.isArray(value)) {
      for (const item of value) walk(item, `${pattern}[]`)
      return
    }
    if (!value || typeof value !== 'object') return
    const isMap = Object.prototype.hasOwnProperty.call(schema, join(pattern, '*'))
    const checked = Object.prototype.hasOwnProperty.call(schema, pattern)
    if (checked) patterns.add(pattern)
    for (const [key, child] of Object.entries(value)) {
      if (checked && !isMap) fields.add(`${pattern}|${key}`)
      walk(child, join(pattern, isMap ? '*' : key))
    }
  }
  walk(meta, '')
  return { fields, patterns }
}

/**
 * 서버 meta에 있던 필드 중 로컬 meta에서 빠지는 것. 익스텐션이 읽는 필드(schema에 있는 필드)만 보고하고,
 * 상위 객체 자체가 로컬에 없는 경우(예: 프리셋이나 슬롯을 지움)는 데이터 삭제로 보고 보고하지 않는다.
 *
 * @returns {Array<{path:string, field:string}>}
 */
function findRemovedFields(schema, remoteMeta, localMeta) {
  const before = collectFieldPaths(schema, remoteMeta)
  const after = collectFieldPaths(schema, localMeta)
  const out = []
  for (const id of before.fields) {
    if (after.fields.has(id)) continue
    const [pattern, field] = id.split('|')
    if (!after.patterns.has(pattern)) continue
    if (!(schema[pattern] ?? []).includes(field)) continue
    out.push({ path: pattern || '(root)', field })
  }
  return out
}

/** files[역할]과 editorOnly[역할]을 합친 스키마 — 구조(맵·검사 위치)는 같고 필드 목록만 합친다 */
function mergeSchema(known = {}, editorOnly = {}) {
  const out = { ...known }
  for (const [pattern, fields] of Object.entries(editorOnly)) out[pattern] = [...(out[pattern] ?? []), ...fields]
  return out
}

function join(pattern, key) {
  return pattern ? `${pattern}.${key}` : key
}

/** 파일 이름 규칙 — 공백·한글 등 URL에서 문제가 되는 문자, 대소문자만 다른 중복 */
function checkFileNames(keys) {
  const warnings = []
  const seen = new Map()
  for (const key of keys) {
    const name = path.posix.basename(key)
    if (!/^[A-Za-z0-9._-]+$/.test(name)) {
      warnings.push({ code: 'fileName', message: `파일 이름에 영문·숫자·.-_ 외의 문자가 있습니다: ${name}`, file: key })
    }
    const lower = key.toLowerCase()
    if (seen.has(lower) && seen.get(lower) !== key) {
      warnings.push({ code: 'fileName', message: `대소문자만 다른 파일이 있습니다: ${seen.get(lower)}, ${key}`, file: key })
    }
    seen.set(lower, key)
  }
  return warnings
}

function arr(v) {
  return Array.isArray(v) ? v : []
}

function obj(v) {
  return v && typeof v === 'object' && !Array.isArray(v) ? v : {}
}

module.exports = { collectReferences, findUnknownFields, findRemovedFields, mergeSchema, checkFileNames }
