'use strict'

const fs = require('node:fs/promises')
const path = require('node:path')
const { KEYS, CHARACTER_ID, modelFileBase } = require('./config')

/**
 * 올리지 않는 파일 — 백업·임시·OS 파일, 에디터 설정.
 * 에디터 루트의 ExpressionEditorConfig.ini, spaces/, vrSpace/는 수집 대상 폴더(sources)가 아니라서 애초에 읽지 않는다.
 * sources가 그 폴더를 가리키면 collectLocalFiles가 거부한다.
 */
const EXCLUDED = [/\.ini$/i, /\.bak$/i, /\.broken-/i, /_bk\./i, /_backup_\d/i, /^\./, /^Thumbs\.db$/i, /\.tmp$/i, /\.log$/i]

/** 업로드 원본으로 쓰면 안 되는 에디터 폴더 — Space Editor는 개발 중이라 비활성화 상태 */
const FORBIDDEN_SOURCE_DIRS = ['spaces', 'vrSpace']

function isExcluded(fileName) {
  return EXCLUDED.some((re) => re.test(fileName))
}

/** 폴더 안의 파일(하위 폴더 제외)을 이름순으로 돌려준다. 폴더가 없으면 빈 배열 */
async function listFiles(dir) {
  let entries
  try {
    entries = await fs.readdir(dir, { withFileTypes: true })
  } catch (err) {
    if (err.code === 'ENOENT') return []
    throw err
  }
  return entries
    .filter((e) => e.isFile())
    .map((e) => e.name)
    .sort()
}

async function statOrNull(filePath) {
  try {
    const st = await fs.stat(filePath)
    return st.isFile() ? st : null
  } catch (err) {
    if (err.code === 'ENOENT') return null
    throw err
  }
}

/**
 * 에디터 폴더를 버킷 키로 매핑한다.
 *
 * @param {object} sources 에디터 폴더 경로 (요청서 4번 인터페이스)
 * @param {string} characterId 예: 'seoha-rorr'
 * @returns {Promise<{files: Array<{key:string, localPath:string, size:number, role:string}>, skipped: Array<{localPath:string, reason:string}>, missingSources: string[]}>}
 */
async function collectLocalFiles(sources, characterId) {
  if (!CHARACTER_ID.test(characterId)) {
    throw Object.assign(new Error(`캐릭터 id는 소문자·숫자·하이픈만 쓸 수 있습니다: ${characterId}`), { code: 'INVALID_CHARACTER_ID' })
  }
  for (const [name, value] of Object.entries(sources)) {
    if (value && FORBIDDEN_SOURCE_DIRS.some((d) => String(value).split(/[\\/]/).includes(d))) {
      throw Object.assign(new Error(`업로드 대상이 아닌 폴더입니다 (${name}): ${value}`), { code: 'FORBIDDEN_SOURCE' })
    }
  }
  const root = KEYS.characterRoot(characterId)
  const modelBase = modelFileBase(characterId)
  const files = []
  const skipped = []
  const missingSources = []

  const add = async (localPath, key, role) => {
    const st = await statOrNull(localPath)
    if (!st) return false
    files.push({ key, localPath, size: st.size, role })
    return true
  }

  const addDir = async (dir, keyPrefix, role, accept = () => true) => {
    if (!dir) return
    const names = await listFiles(dir)
    if (!names.length) missingSources.push(dir)
    for (const name of names) {
      const localPath = path.join(dir, name)
      if (isExcluded(name)) {
        skipped.push({ localPath, reason: 'excluded' })
        continue
      }
      if (!accept(name)) {
        skipped.push({ localPath, reason: 'unsupported' })
        continue
      }
      await add(localPath, `${keyPrefix}/${name}`, role)
    }
  }

  // 모델: 로컬 파일 이름과 관계없이 <캐릭터_id>.vrm(.meta)로 올린다 — 익스텐션은 고정 이름으로 읽는다
  if (sources.vrmPath) {
    if (!(await add(sources.vrmPath, `${root}/models/${modelBase}.vrm`, 'model'))) missingSources.push(sources.vrmPath)
    if (!(await add(`${sources.vrmPath}.meta`, `${root}/models/${modelBase}.vrm.meta`, 'characterMeta')))
      missingSources.push(`${sources.vrmPath}.meta`)
  }

  await addDir(sources.imageDir, `${root}/img`, 'image', (n) => /\.(png|svg|jpe?g|webp)$/i.test(n))
  await addDir(sources.propsDir, `${root}/props`, 'prop', (n) => /\.glb$/i.test(n))
  await addDir(sources.emotionLinkerDir, `${root}/emotionLinker`, 'emotionLinker', (n) => /\.meta$/i.test(n))

  if (sources.effectsMetaPath) {
    if (!(await add(sources.effectsMetaPath, `${root}/effects/effects.meta`, 'effectsMeta'))) missingSources.push(sources.effectsMetaPath)
  }

  await addDir(sources.animationsDir, KEYS.sharedAnimations, 'animation', (n) => /\.vrma$/i.test(n) || n === 'animations.meta')
  for (const f of files) if (f.key === `${KEYS.sharedAnimations}/animations.meta`) f.role = 'animationsMeta'

  return { files, skipped, missingSources }
}

/**
 * 리소스 레포(버킷과 같은 구조)를 plan()의 sources로 바꾼다. CI의 PR 검사·prod 반영에서 쓴다.
 */
function sourcesFromRepo(repoRoot, characterId) {
  const root = path.join(repoRoot, KEYS.characterRoot(characterId))
  return {
    vrmPath: path.join(root, 'models', `${modelFileBase(characterId)}.vrm`),
    animationsDir: path.join(repoRoot, KEYS.sharedAnimations),
    imageDir: path.join(root, 'img'),
    propsDir: path.join(root, 'props'),
    effectsMetaPath: path.join(root, 'effects', 'effects.meta'),
    emotionLinkerDir: path.join(root, 'emotionLinker'),
  }
}

/** 리소스 레포의 캐릭터 폴더. 규칙(models/<id_snake>.vrm)에 맞는 것만 characters, 나머지(옛 폴더 등)는 ignored */
async function repoCharacters(repoRoot) {
  const dir = path.join(repoRoot, 'vrm', 'characters')
  let entries = []
  try {
    entries = await fs.readdir(dir, { withFileTypes: true })
  } catch (err) {
    if (err.code !== 'ENOENT') throw err
  }
  const out = { characters: [], ignored: [] }
  for (const e of entries) {
    if (!e.isDirectory() || e.name === path.posix.basename(KEYS.sharedAnimations)) continue
    const model = path.join(dir, e.name, 'models', `${modelFileBase(e.name)}.vrm`)
    const ok = CHARACTER_ID.test(e.name) && (await statOrNull(model))
    ;(ok ? out.characters : out.ignored).push(e.name)
  }
  out.characters.sort()
  out.ignored.sort()
  return out
}

/** 업로드 대상 키가 들어갈 수 있는 버킷 접두사 — 서버에만 있는 파일을 찾을 때 쓴다 */
function managedPrefixes(characterId) {
  return [`${KEYS.characterRoot(characterId)}/`, `${KEYS.sharedAnimations}/`]
}

const CONTENT_TYPES = {
  '.meta': 'application/json',
  '.json': 'application/json',
  '.vrm': 'model/gltf-binary',
  '.vrma': 'model/gltf-binary',
  '.glb': 'model/gltf-binary',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
}

function contentTypeFor(key) {
  return CONTENT_TYPES[path.extname(key).toLowerCase()] ?? 'application/octet-stream'
}

module.exports = { collectLocalFiles, managedPrefixes, contentTypeFor, isExcluded, sourcesFromRepo, repoCharacters }
